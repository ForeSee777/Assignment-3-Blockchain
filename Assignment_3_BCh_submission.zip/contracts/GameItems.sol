// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";
import "@openzeppelin/contracts/token/ERC1155/extensions/ERC1155Supply.sol";

contract GameItems is ERC1155, ERC1155Supply, Ownable {
    uint256 public constant GOLD = 1;
    uint256 public constant WOOD = 2;
    uint256 public constant IRON = 3;
    uint256 public constant LEGENDARY_SWORD = 1001;
    uint256 public constant DRAGON_SHIELD = 1002;

    struct Recipe {
        uint256 goldCost;
        uint256 woodCost;
        uint256 ironCost;
        bool exists;
    }

    mapping(uint256 => Recipe) public recipes;
    mapping(uint256 => bool) public supportedTokenIds;

    event Crafted(address indexed account, uint256 indexed itemId, uint256 amount);
    event RecipeConfigured(
        uint256 indexed itemId,
        uint256 goldCost,
        uint256 woodCost,
        uint256 ironCost
    );

    error UnsupportedTokenId(uint256 tokenId);
    error InvalidAmount();
    error MissingRecipe(uint256 tokenId);

    constructor(string memory baseUri) ERC1155(baseUri) Ownable(msg.sender) {
        _registerToken(GOLD);
        _registerToken(WOOD);
        _registerToken(IRON);
        _registerToken(LEGENDARY_SWORD);
        _registerToken(DRAGON_SHIELD);

        _setRecipe(LEGENDARY_SWORD, 100, 25, 10);
        _setRecipe(DRAGON_SHIELD, 60, 40, 30);
    }

    function mint(address to, uint256 id, uint256 amount, bytes memory data) external onlyOwner {
        _assertSupported(id);
        if (amount == 0) revert InvalidAmount();
        _mint(to, id, amount, data);
    }

    function mintBatch(
        address to,
        uint256[] calldata ids,
        uint256[] calldata amounts,
        bytes calldata data
    ) external onlyOwner {
        require(ids.length == amounts.length, "GameItems: length mismatch");

        for (uint256 index = 0; index < ids.length; index++) {
            _assertSupported(ids[index]);
            if (amounts[index] == 0) revert InvalidAmount();
        }

        _mintBatch(to, ids, amounts, data);
    }

    function craft(uint256 itemId, uint256 amount) external {
        Recipe memory recipe = recipes[itemId];
        if (!recipe.exists) revert MissingRecipe(itemId);
        if (amount == 0) revert InvalidAmount();

        _burn(msg.sender, GOLD, recipe.goldCost * amount);
        _burn(msg.sender, WOOD, recipe.woodCost * amount);
        _burn(msg.sender, IRON, recipe.ironCost * amount);
        _mint(msg.sender, itemId, amount, "");

        emit Crafted(msg.sender, itemId, amount);
    }

    function setBaseUri(string calldata newBaseUri) external onlyOwner {
        _setURI(newBaseUri);
    }

    function setRecipe(
        uint256 itemId,
        uint256 goldCost,
        uint256 woodCost,
        uint256 ironCost
    ) external onlyOwner {
        _assertSupported(itemId);
        _setRecipe(itemId, goldCost, woodCost, ironCost);
    }

    function uri(uint256 tokenId) public view override returns (string memory) {
        _assertSupported(tokenId);
        return super.uri(tokenId);
    }

    function _setRecipe(
        uint256 itemId,
        uint256 goldCost,
        uint256 woodCost,
        uint256 ironCost
    ) internal {
        recipes[itemId] = Recipe({
            goldCost: goldCost,
            woodCost: woodCost,
            ironCost: ironCost,
            exists: true
        });

        emit RecipeConfigured(itemId, goldCost, woodCost, ironCost);
    }

    function _registerToken(uint256 tokenId) internal {
        supportedTokenIds[tokenId] = true;
    }

    function _assertSupported(uint256 tokenId) internal view {
        if (!supportedTokenIds[tokenId]) revert UnsupportedTokenId(tokenId);
    }

    function _update(
        address from,
        address to,
        uint256[] memory ids,
        uint256[] memory values
    ) internal override(ERC1155, ERC1155Supply) {
        super._update(from, to, ids, values);
    }
}
