// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./PriceFeedConsumer.sol";

contract PriceDependentVault is ReentrancyGuard, PriceFeedConsumer {
    mapping(address => uint256) public deposits;
    uint256 public immutable minimumWithdrawalPrice;

    event Deposited(address indexed account, uint256 ethAmount, uint256 usdValue);
    event Withdrawn(address indexed account, uint256 ethAmount, uint256 usdValue);

    error ZeroAmount();
    error InsufficientBalance(address account, uint256 requested, uint256 available);
    error PriceBelowThreshold(uint256 currentPrice, uint256 minimumRequired);

    constructor(
        address priceFeedAddress,
        uint256 stalePriceDelay_,
        uint256 minimumWithdrawalPrice_
    ) PriceFeedConsumer(priceFeedAddress, stalePriceDelay_) {
        require(minimumWithdrawalPrice_ > 0, "PriceDependentVault: invalid threshold");
        minimumWithdrawalPrice = minimumWithdrawalPrice_;
    }

    function deposit() external payable nonReentrant {
        if (msg.value == 0) revert ZeroAmount();

        uint256 usdValue = previewUsdValue(msg.value);
        deposits[msg.sender] += msg.value;

        emit Deposited(msg.sender, msg.value, usdValue);
    }

    function withdraw(uint256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();

        uint256 depositedAmount = deposits[msg.sender];
        if (depositedAmount < amount) {
            revert InsufficientBalance(msg.sender, amount, depositedAmount);
        }

        uint256 currentPrice = getLatestPrice();
        if (currentPrice < minimumWithdrawalPrice) {
            revert PriceBelowThreshold(currentPrice, minimumWithdrawalPrice);
        }

        deposits[msg.sender] = depositedAmount - amount;
        uint256 usdValue = _convertEthToUsd(amount, currentPrice);

        (bool success, ) = payable(msg.sender).call{value: amount}("");
        require(success, "PriceDependentVault: transfer failed");

        emit Withdrawn(msg.sender, amount, usdValue);
    }

    function previewUsdValue(uint256 ethAmount) public view returns (uint256) {
        return _convertEthToUsd(ethAmount, getLatestPrice());
    }

    function getDepositValueInUsd(address account) external view returns (uint256) {
        return previewUsdValue(deposits[account]);
    }

    function _convertEthToUsd(uint256 ethAmount, uint256 normalizedPrice) internal pure returns (uint256) {
        return (ethAmount * normalizedPrice) / 1 ether;
    }
}
