// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./interfaces/AggregatorV3Interface.sol";

contract PriceFeedConsumer {
    AggregatorV3Interface public immutable priceFeed;
    uint256 public immutable stalePriceDelay;

    error InvalidPrice(int256 answer);
    error StalePrice(uint256 updatedAt, uint256 currentTimestamp);
    error InvalidPriceFeed(address priceFeedAddress);
    error InvalidStaleWindow();

    constructor(address priceFeedAddress, uint256 stalePriceDelay_) {
        if (priceFeedAddress == address(0)) revert InvalidPriceFeed(priceFeedAddress);
        if (stalePriceDelay_ == 0) revert InvalidStaleWindow();

        priceFeed = AggregatorV3Interface(priceFeedAddress);
        stalePriceDelay = stalePriceDelay_;
    }

    function getLatestPrice() public view returns (uint256) {
        (uint256 normalizedPrice, , ) = getLatestPriceData();
        return normalizedPrice;
    }

    function getLatestPriceData() public view returns (uint256 normalizedPrice, uint8 feedDecimals, uint256 updatedAt) {
        (, int256 answer, , uint256 feedUpdatedAt, ) = priceFeed.latestRoundData();
        if (answer <= 0) revert InvalidPrice(answer);
        if (block.timestamp > feedUpdatedAt + stalePriceDelay) {
            revert StalePrice(feedUpdatedAt, block.timestamp);
        }

        feedDecimals = priceFeed.decimals();
        updatedAt = feedUpdatedAt;
        normalizedPrice = _scaleTo18(uint256(answer), feedDecimals);
    }

    function _scaleTo18(uint256 value, uint8 decimals_) internal pure returns (uint256) {
        if (decimals_ == 18) {
            return value;
        }

        if (decimals_ < 18) {
            return value * (10 ** (18 - decimals_));
        }

        return value / (10 ** (decimals_ - 18));
    }
}
