// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";

contract SimpleAMM {
    using SafeERC20 for IERC20;

    IERC20 public immutable token0;
    IERC20 public immutable token1;

    uint256 public reserve0;
    uint256 public reserve1;
    uint256 public totalLiquidity;

    mapping(address => uint256) public liquidityBalance;

    event LiquidityAdded(
        address indexed provider,
        uint256 amount0,
        uint256 amount1,
        uint256 sharesMinted,
        uint256 reserve0After,
        uint256 reserve1After,
        uint256 totalLiquidityAfter
    );

    event LiquidityRemoved(
        address indexed provider,
        uint256 amount0,
        uint256 amount1,
        uint256 sharesBurned,
        uint256 reserve0After,
        uint256 reserve1After,
        uint256 totalLiquidityAfter
    );

    event Swap(
        address indexed trader,
        address indexed tokenIn,
        address indexed tokenOut,
        uint256 amountIn,
        uint256 amountOut,
        uint256 reserve0After,
        uint256 reserve1After
    );

    error InvalidToken(address tokenAddress);
    error IdenticalTokenAddresses();
    error ZeroAmount();
    error ZeroShares();
    error InvalidLiquidityRatio();
    error SlippageExceeded(uint256 actualOut, uint256 minAmountOut);
    error InsufficientLiquidity();

    constructor(address token0_, address token1_) {
        if (token0_ == address(0)) revert InvalidToken(token0_);
        if (token1_ == address(0)) revert InvalidToken(token1_);
        if (token0_ == token1_) revert IdenticalTokenAddresses();

        token0 = IERC20(token0_);
        token1 = IERC20(token1_);
    }

    function addLiquidity(uint256 amount0, uint256 amount1) external returns (uint256 sharesMinted) {
        if (amount0 == 0 || amount1 == 0) revert ZeroAmount();

        if (totalLiquidity == 0) {
            sharesMinted = Math.sqrt(amount0 * amount1);
        } else {
            if (amount0 * reserve1 != amount1 * reserve0) revert InvalidLiquidityRatio();
            uint256 sharesFromToken0 = (amount0 * totalLiquidity) / reserve0;
            uint256 sharesFromToken1 = (amount1 * totalLiquidity) / reserve1;
            sharesMinted = sharesFromToken0 < sharesFromToken1 ? sharesFromToken0 : sharesFromToken1;
        }

        if (sharesMinted == 0) revert ZeroShares();

        token0.safeTransferFrom(msg.sender, address(this), amount0);
        token1.safeTransferFrom(msg.sender, address(this), amount1);

        reserve0 += amount0;
        reserve1 += amount1;
        totalLiquidity += sharesMinted;
        liquidityBalance[msg.sender] += sharesMinted;

        emit LiquidityAdded(
            msg.sender,
            amount0,
            amount1,
            sharesMinted,
            reserve0,
            reserve1,
            totalLiquidity
        );
    }

    function removeLiquidity(uint256 sharesBurned) external returns (uint256 amount0, uint256 amount1) {
        if (sharesBurned == 0) revert ZeroAmount();
        uint256 providerShares = liquidityBalance[msg.sender];
        if (providerShares < sharesBurned) revert InsufficientLiquidity();

        amount0 = (sharesBurned * reserve0) / totalLiquidity;
        amount1 = (sharesBurned * reserve1) / totalLiquidity;
        if (amount0 == 0 || amount1 == 0) revert ZeroAmount();

        liquidityBalance[msg.sender] = providerShares - sharesBurned;
        totalLiquidity -= sharesBurned;
        reserve0 -= amount0;
        reserve1 -= amount1;

        token0.safeTransfer(msg.sender, amount0);
        token1.safeTransfer(msg.sender, amount1);

        emit LiquidityRemoved(
            msg.sender,
            amount0,
            amount1,
            sharesBurned,
            reserve0,
            reserve1,
            totalLiquidity
        );
    }

    function swapToken0ForToken1(
        uint256 amountIn,
        uint256 minAmountOut
    ) external returns (uint256 amountOut) {
        amountOut = _quoteSwap(amountIn, reserve0, reserve1);
        if (amountOut < minAmountOut) revert SlippageExceeded(amountOut, minAmountOut);

        token0.safeTransferFrom(msg.sender, address(this), amountIn);
        token1.safeTransfer(msg.sender, amountOut);

        reserve0 += amountIn;
        reserve1 -= amountOut;

        emit Swap(msg.sender, address(token0), address(token1), amountIn, amountOut, reserve0, reserve1);
    }

    function swapToken1ForToken0(
        uint256 amountIn,
        uint256 minAmountOut
    ) external returns (uint256 amountOut) {
        amountOut = _quoteSwap(amountIn, reserve1, reserve0);
        if (amountOut < minAmountOut) revert SlippageExceeded(amountOut, minAmountOut);

        token1.safeTransferFrom(msg.sender, address(this), amountIn);
        token0.safeTransfer(msg.sender, amountOut);

        reserve1 += amountIn;
        reserve0 -= amountOut;

        emit Swap(msg.sender, address(token1), address(token0), amountIn, amountOut, reserve0, reserve1);
    }

    function getAmountOut(uint256 amountIn, address tokenIn) external view returns (uint256) {
        if (tokenIn == address(token0)) {
            return _quoteSwap(amountIn, reserve0, reserve1);
        }

        if (tokenIn == address(token1)) {
            return _quoteSwap(amountIn, reserve1, reserve0);
        }

        revert InvalidToken(tokenIn);
    }

    function getReserves() external view returns (uint256, uint256) {
        return (reserve0, reserve1);
    }

    function _quoteSwap(
        uint256 amountIn,
        uint256 reserveIn,
        uint256 reserveOut
    ) internal pure returns (uint256 amountOut) {
        if (amountIn == 0) revert ZeroAmount();
        if (reserveIn == 0 || reserveOut == 0) revert InsufficientLiquidity();

        uint256 amountInWithFee = amountIn * 997;
        uint256 numerator = amountInWithFee * reserveOut;
        uint256 denominator = (reserveIn * 1000) + amountInWithFee;
        amountOut = numerator / denominator;

        if (amountOut == 0 || amountOut >= reserveOut) revert InsufficientLiquidity();
    }
}
