// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";

contract Vault is ERC4626, Ownable {
    using Math for uint256;

    event Harvest(address indexed caller, uint256 assetsAdded, uint256 totalAssetsAfterHarvest);

    constructor(
        IERC20 asset_,
        string memory name_,
        string memory symbol_
    ) ERC20(name_, symbol_) ERC4626(asset_) Ownable(msg.sender) {}

    function harvest(uint256 assets) external onlyOwner {
        require(assets > 0, "Vault: zero harvest");
        IERC20 vaultAsset = IERC20(asset());
        bool received = vaultAsset.transferFrom(msg.sender, address(this), assets);
        require(received, "Vault: transfer failed");

        emit Harvest(msg.sender, assets, totalAssets());
    }

    function _convertToShares(
        uint256 assets,
        Math.Rounding rounding
    ) internal view override returns (uint256) {
        uint256 supply = totalSupply();
        uint256 managedAssets = totalAssets();

        if (supply == 0 || managedAssets == 0) {
            return assets;
        }

        return assets.mulDiv(supply, managedAssets, rounding);
    }

    function _convertToAssets(
        uint256 shares,
        Math.Rounding rounding
    ) internal view override returns (uint256) {
        uint256 supply = totalSupply();
        uint256 managedAssets = totalAssets();

        if (supply == 0 || managedAssets == 0) {
            return shares;
        }

        return shares.mulDiv(managedAssets, supply, rounding);
    }
}
