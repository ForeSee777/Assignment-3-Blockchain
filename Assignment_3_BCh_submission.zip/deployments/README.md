# Deployment outputs

Running `npm run deploy:base-sepolia` or a Sepolia deployment variant will create JSON receipts in this folder.

Those files are then used by:

- `scripts/verify.js` for explorer verification
- `scripts/gasComparison.js` for the L1 vs L2 gas report
- `subgraph/subgraph.yaml` after you replace the placeholder address with the deployed contract address
