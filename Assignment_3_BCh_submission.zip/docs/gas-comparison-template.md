# Gas Comparison Workflow

After deploying to both Sepolia and Base Sepolia:

1. Confirm that `deployments/sepolia.json` exists
2. Confirm that `deployments/baseSepolia.json` exists
3. Run:

```bash
npm run quote:gas
```

That script generates `docs/gas-comparison.md` with a table comparing the recorded gas usage of identical operations across L1 and L2.

## Table format

| Operation | L1 Gas | L2 Gas |
| --- | ---: | ---: |
| mintAsset | fill from script | fill from script |
| mintQuoteAsset | fill from script | fill from script |
| approveAmmAsset | fill from script | fill from script |
| approveAmmQuoteAsset | fill from script | fill from script |
| ammAddLiquidity | fill from script | fill from script |
| ammSwapAssetForQuote | fill from script | fill from script |
| ammSwapQuoteForAsset | fill from script | fill from script |
| ammRemoveLiquidity | fill from script | fill from script |
| approveDeposit | fill from script | fill from script |
| vaultDeposit | fill from script | fill from script |
| mintYield | fill from script | fill from script |
| approveHarvest | fill from script | fill from script |
| vaultHarvest | fill from script | fill from script |
| vaultRedeem | fill from script | fill from script |

## Expected conclusion

The gas used by the EVM operations may be in the same general range, but the user-facing fee paid on L2 should be meaningfully lower because Base Sepolia inherits rollup fee economics instead of L1 settlement pricing.
