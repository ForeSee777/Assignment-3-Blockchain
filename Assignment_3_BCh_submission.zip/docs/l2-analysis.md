# Layer 2 Technical Analysis

## Optimistic Rollups vs ZK-Rollups

Optimistic rollups and ZK-rollups both scale Ethereum by executing transactions off the main chain and posting compressed data back to Ethereum, but they differ in how they prove correctness. Optimistic systems assume submitted state transitions are valid by default. They rely on fraud proofs and a challenge window. If an invalid batch is posted, honest participants can contest it and force the system to recompute or reject the fraudulent state transition. Arbitrum and Optimism are the most visible examples of this approach.

ZK-rollups take the opposite path. Instead of assuming validity and waiting for disputes, they submit a cryptographic proof showing that the batched state transition was computed correctly. Ethereum verifies the proof on-chain, which lets the L2 finalize state with much stronger immediate assurances. zkSync, Scroll, and Starknet all fit somewhere in this proof-oriented family, although they differ in prover design and virtual machine model.

Architecturally, optimistic rollups are often easier to make EVM-compatible because they can reuse more of the L1 execution model and rely on post-execution disputes for safety. That is one reason they reached production maturity earlier. ZK-rollups historically faced the harder engineering challenge because proof generation for general EVM execution is computationally expensive and complex. Over time, zkEVM research has narrowed that gap, but prover cost and engineering complexity are still major design constraints.

Finality is one of the clearest differences from a user perspective. Optimistic rollups can show fast local confirmations, but economic finality for withdrawals to L1 is delayed by the fraud-proof challenge period, which may last several days. That is the cost of giving the network time to detect fraud. ZK-rollups can settle much faster once the proof is generated and verified, because the validity proof replaces the need for a dispute window. In practice, the user experience depends on prover latency, batch submission cadence, and bridge design, but the general rule is that ZK systems offer faster final settlement while optimistic systems offer simpler proving assumptions.

## Security Model and Inheritance from Ethereum

Both models try to inherit Ethereum security, but they do so differently. An optimistic rollup inherits Ethereum by anchoring data and dispute resolution to L1. If the rollup operator posts a fraudulent state root, anyone with access to the transaction data can submit a fraud proof during the challenge window. The system is secure as long as at least one honest challenger is online, the data needed to reconstruct state is available, and the L1 contracts correctly enforce dispute outcomes.

ZK-rollups inherit Ethereum by anchoring both data and proof verification to L1. The L1 contract only accepts state transitions that come with valid zero-knowledge proofs. That means the trust assumption shifts away from challengers and toward the soundness of the proving system, the correctness of the circuits, and the correctness of the verifier contract deployed on Ethereum. In other words, optimistic systems need honest watchers, while ZK systems need correct cryptography and proof infrastructure.

Neither model is “free security.” Both still depend on sequencer behavior, upgrade keys, and operational centralization. Many production L2s have a single sequencer or an upgrade-controlled bridge contract, which means the practical security picture includes governance and operator risk on top of the core rollup model. For a developer deciding where to deploy, the headline “inherits Ethereum security” is directionally true, but the real answer lives in the details of upgradeability, pause rights, forced inclusion mechanisms, and escape hatches.

## Data Availability, Calldata, and Blobs

Rollups need transaction data to be available so anyone can reconstruct the L2 state. Historically, that data was published to Ethereum as calldata. Calldata is expensive because every byte is permanently stored in L1 history, but it guarantees availability to verifiers and users. This model is simple and secure, which is why it became the default foundation for early rollups.

EIP-4844 introduced blobs, which are designed specifically for data-heavy workloads like rollups. A blob stores large transaction data payloads more cheaply than calldata because Ethereum does not need to keep that data forever in the same way. The network retains blob data long enough for rollup participants to verify and reconstruct the state transition, while permanent execution commitments stay small. This changes the economics of L2s substantially. Rollups that previously paid high calldata costs can shift batch data into blobs and lower user fees.

That does not eliminate data-availability risk altogether. Rollups still need robust node infrastructure to fetch and preserve blob data while it is available, and systems that move beyond Ethereum DA into alternative data-availability layers introduce a new trust tradeoff. But in the Ethereum-centric model, blobs are a major upgrade because they cut costs without discarding the core security story of keeping L2 data anchored to Ethereum.

## Bridge Security and Cross-Chain Risk

Bridges are often the weakest link in multi-chain systems because they concentrate assets and depend on message validation across trust boundaries. Even if an L2 execution layer is secure, a vulnerable bridge can still be catastrophic. Wormhole and Ronin are the classic warning examples. Wormhole suffered a signature-verification bug that allowed an attacker to mint wrapped assets without proper backing. Ronin was compromised through validator key control, showing that bridge security is often as much about operational trust and validator decentralization as about pure smart contract correctness.

Cross-chain messaging increases attack surface because it relies on assumptions about message ordering, replay protection, verifier correctness, and the behavior of relayers or guardians. A bridge bug can bypass the security properties of the underlying chain because the issue lives in the settlement or attestation mechanism rather than in the chain’s consensus layer. For developers, that means bridge choice matters as much as chain choice when designing an L2 application.

Native rollup bridges are generally safer than third-party bridges because they are closer to the core rollup protocol and are enforced by L1 settlement contracts. Even then, users still face upgrade risk, challenge-window risk in optimistic systems, and delays during emergency shutdown or censorship scenarios. Fast bridges improve UX but often do so by adding liquidity providers or off-chain relayers, which creates additional trust assumptions.

## Cost Analysis: When L2 Makes More Sense Than L1

Deploying on L2 makes the most sense when the application expects frequent state updates, smaller-value transactions, or user interactions that would be too expensive on Ethereum L1. Games, DEXes, social protocols, NFT marketplaces, and consumer-facing wallets all benefit from lower fees and faster confirmations. In this assignment, ERC-1155 crafting, ERC-4626 deposits, and price-dependent withdrawals are all examples of interactions that users may perform repeatedly. Running them on L1 would be needlessly expensive compared with a rollup.

L1 still makes sense when the contract manages very high-value settlement, requires direct access to the deepest liquidity, or must minimize bridge assumptions. Governance roots, final accounting layers, and core settlement contracts often stay on Ethereum because the security premium is worth paying. The choice is therefore not simply “L2 is cheaper.” It is whether the application’s trust, latency, and liquidity needs justify L1 costs.

For most application-layer systems, the best pattern is hybrid. Put frequent user interaction on L2, anchor the security and settlement guarantees to Ethereum, and keep bridge exposure as small and well-audited as possible. That is why this assignment’s deployment section focuses on an L2 testnet: it reflects the direction real-world applications are already taking.
