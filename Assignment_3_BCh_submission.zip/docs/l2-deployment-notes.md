# L2 Deployment Notes

## Chosen networks

- `sepolia` for the L1 reference deployment used in gas comparison
- `baseSepolia` for the Layer 2 deployment required by the assignment

## Prepared contracts for deployment

- `MockERC20`
- `QuoteAsset`
- `SimpleAMM`
- `Vault`
- `GameItems`
- `PriceFeedConsumer`
- `PriceDependentVault`

## Commands

```bash
npm run deploy:sepolia
npm run deploy:base-sepolia
npm run verify:sepolia
npm run verify:base-sepolia
npm run quote:gas
```

## What the deployment script does

The deployment script deploys the ERC-20 asset token, a quote token, a simple AMM, the ERC-4626 vault, the ERC-1155 game contract, and the oracle contracts. It then executes more than five follow-up transactions:

1. Mint ERC-20 assets to the deployer
2. Mint quote assets to the deployer
3. Approve token0 for AMM liquidity
4. Approve token1 for AMM liquidity
5. Add liquidity
6. Swap token0 for token1
7. Swap token1 for token0
8. Remove a portion of liquidity
9. Approve the vault
10. Deposit into the vault
11. Mint additional yield assets
12. Approve harvest
13. Harvest into the vault
14. Redeem shares

Each transaction is written to `deployments/<network>.json` together with gas usage so the gas comparison report can be generated automatically after both the L1 and L2 runs are complete.

## Why live explorer links are not already filled in

The workspace did not contain:

- a funded testnet private key
- Sepolia or Base Sepolia RPC credentials
- explorer API keys for verification
- a confirmed live Chainlink feed address to use for the target testnet

Because of that, the assignment package includes the full deployment and verification workflow, but not pre-generated live explorer links or screenshots. Once the `.env` file is filled in, the missing deliverables can be produced directly from the included scripts.

## Explorer links to fill after deployment

- Sepolia contract addresses: `deployments/sepolia.json`
- Base Sepolia contract addresses: `deployments/baseSepolia.json`
- Verified pages:
  - `https://sepolia.etherscan.io/address/<address>#code`
  - `https://sepolia.basescan.org/address/<address>#code`

## Screenshot checklist

- Verified `SimpleAMM` contract page on Base Sepolia
- At least one `Swap` transaction on Base Sepolia
- At least one liquidity add/remove transaction on Base Sepolia
- Deployed `Vault` contract page on Base Sepolia
- Verified `GameItems` or `PriceDependentVault` contract page on Base Sepolia
- Optional Chainlink live price read if a live feed address is configured
