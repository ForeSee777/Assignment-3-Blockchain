require("dotenv").config();

const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const { ethers, network } = hre;
  const [deployer] = await ethers.getSigners();
  const staleWindow = BigInt(process.env.PRICE_STALE_WINDOW || "3600");
  const withdrawalThreshold = BigInt(
    process.env.WITHDRAW_PRICE_THRESHOLD || "3000000000000000000000"
  );

  const feedEnvKey = network.name === "baseSepolia" ? "BASE_SEPOLIA_ETH_USD_FEED" : "SEPOLIA_ETH_USD_FEED";
  const configuredFeed = process.env[feedEnvKey];
  const txLog = [];

  const recordTx = async (label, txPromise) => {
    const tx = await txPromise;
    const receipt = await tx.wait();
    txLog.push({
      label,
      hash: receipt.hash,
      gasUsed: receipt.gasUsed.toString()
    });
    return receipt;
  };

  console.log(`Deploying with ${deployer.address} on ${network.name}`);

  const MockERC20 = await ethers.getContractFactory("MockERC20");
  const SimpleAMM = await ethers.getContractFactory("SimpleAMM");
  const Vault = await ethers.getContractFactory("Vault");
  const GameItems = await ethers.getContractFactory("GameItems");
  const PriceFeedConsumer = await ethers.getContractFactory("PriceFeedConsumer");
  const PriceDependentVault = await ethers.getContractFactory("PriceDependentVault");
  const MockAggregator = await ethers.getContractFactory("MockAggregator");

  const asset = await MockERC20.deploy("Assignment Asset", "AAS", 18);
  await asset.waitForDeployment();

  const quoteAsset = await MockERC20.deploy("Assignment Quote Asset", "AQT", 18);
  await quoteAsset.waitForDeployment();

  const amm = await SimpleAMM.deploy(await asset.getAddress(), await quoteAsset.getAddress());
  await amm.waitForDeployment();

  const vault = await Vault.deploy(await asset.getAddress(), "Assignment Yield Vault", "aAAS");
  await vault.waitForDeployment();

  const gameItems = await GameItems.deploy("ipfs://assignment3-game-items/{id}.json");
  await gameItems.waitForDeployment();

  let priceFeedAddress = configuredFeed;
  let mockAggregator = null;

  if (!priceFeedAddress) {
    mockAggregator = await MockAggregator.deploy(8, 3500n * 10n ** 8n, "Mock ETH / USD");
    await mockAggregator.waitForDeployment();
    priceFeedAddress = await mockAggregator.getAddress();
  }

  const consumer = await PriceFeedConsumer.deploy(priceFeedAddress, staleWindow);
  await consumer.waitForDeployment();

  const ethVault = await PriceDependentVault.deploy(
    priceFeedAddress,
    staleWindow,
    withdrawalThreshold
  );
  await ethVault.waitForDeployment();

  await recordTx("mintAsset", asset.mint(deployer.address, ethers.parseEther("3000")));
  await recordTx("mintQuoteAsset", quoteAsset.mint(deployer.address, ethers.parseEther("3000")));
  await recordTx("approveAmmAsset", asset.approve(await amm.getAddress(), ethers.parseEther("1200")));
  await recordTx("approveAmmQuoteAsset", quoteAsset.approve(await amm.getAddress(), ethers.parseEther("1200")));
  await recordTx(
    "ammAddLiquidity",
    amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"))
  );
  await recordTx("ammSwapAssetForQuote", amm.swapToken0ForToken1(ethers.parseEther("25"), 0));
  await recordTx("ammSwapQuoteForAsset", amm.swapToken1ForToken0(ethers.parseEther("15"), 0));
  await recordTx("ammRemoveLiquidity", amm.removeLiquidity(ethers.parseEther("100")));

  await recordTx("approveDeposit", asset.approve(await vault.getAddress(), ethers.parseEther("500")));
  await recordTx("vaultDeposit", vault.deposit(ethers.parseEther("200"), deployer.address));
  await recordTx("mintYield", asset.mint(deployer.address, ethers.parseEther("100")));
  await recordTx("approveHarvest", asset.approve(await vault.getAddress(), ethers.parseEther("100")));
  await recordTx("vaultHarvest", vault.harvest(ethers.parseEther("100")));
  await recordTx("vaultRedeem", vault.redeem(ethers.parseEther("50"), deployer.address, deployer.address));

  const chainId = (await ethers.provider.getNetwork()).chainId;
  const deploymentsDir = path.join(__dirname, "..", "deployments");
  const deploymentPath = path.join(deploymentsDir, `${network.name}.json`);

  if (!fs.existsSync(deploymentsDir)) {
    fs.mkdirSync(deploymentsDir, { recursive: true });
  }

  const payload = {
    network: network.name,
    chainId: chainId.toString(),
    deployer: deployer.address,
    generatedAt: new Date().toISOString(),
    livePriceFeedUsed: Boolean(configuredFeed),
    contracts: {
      mockERC20: {
        address: await asset.getAddress(),
        constructorArguments: ["Assignment Asset", "AAS", 18]
      },
      quoteAsset: {
        address: await quoteAsset.getAddress(),
        constructorArguments: ["Assignment Quote Asset", "AQT", 18]
      },
      simpleAMM: {
        address: await amm.getAddress(),
        constructorArguments: [await asset.getAddress(), await quoteAsset.getAddress()]
      },
      vault: {
        address: await vault.getAddress(),
        constructorArguments: [await asset.getAddress(), "Assignment Yield Vault", "aAAS"]
      },
      gameItems: {
        address: await gameItems.getAddress(),
        constructorArguments: ["ipfs://assignment3-game-items/{id}.json"]
      },
      priceFeedConsumer: {
        address: await consumer.getAddress(),
        constructorArguments: [priceFeedAddress, staleWindow.toString()]
      },
      priceDependentVault: {
        address: await ethVault.getAddress(),
        constructorArguments: [
          priceFeedAddress,
          staleWindow.toString(),
          withdrawalThreshold.toString()
        ]
      }
    },
    transactions: txLog
  };

  if (mockAggregator) {
    payload.contracts.mockAggregator = {
      address: await mockAggregator.getAddress(),
      constructorArguments: [8, (3500n * 10n ** 8n).toString(), "Mock ETH / USD"]
    };
  }

  fs.writeFileSync(deploymentPath, `${JSON.stringify(payload, null, 2)}\n`);

  console.log(`Deployment data written to ${deploymentPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
