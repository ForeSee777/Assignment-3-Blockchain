const fs = require("fs");
const path = require("path");

function loadDeployment(networkName) {
  const deploymentPath = path.join(__dirname, "..", "deployments", `${networkName}.json`);
  if (!fs.existsSync(deploymentPath)) {
    throw new Error(`Missing deployment file for ${networkName}: ${deploymentPath}`);
  }

  return JSON.parse(fs.readFileSync(deploymentPath, "utf8"));
}

function asMap(transactions) {
  return new Map(transactions.map((tx) => [tx.label, tx.gasUsed]));
}

function main() {
  const l1 = loadDeployment("sepolia");
  const l2 = loadDeployment("baseSepolia");
  const l1Tx = asMap(l1.transactions);
  const l2Tx = asMap(l2.transactions);

  const operations = [
    "mintAsset",
    "mintQuoteAsset",
    "approveAmmAsset",
    "approveAmmQuoteAsset",
    "ammAddLiquidity",
    "ammSwapAssetForQuote",
    "ammSwapQuoteForAsset",
    "ammRemoveLiquidity",
    "approveDeposit",
    "vaultDeposit",
    "mintYield",
    "approveHarvest",
    "vaultHarvest",
    "vaultRedeem"
  ];

  const rows = operations.map((label) => {
    const l1Gas = l1Tx.get(label) || "n/a";
    const l2Gas = l2Tx.get(label) || "n/a";
    return `| ${label} | ${l1Gas} | ${l2Gas} |`;
  });

  const report = [
    "# Gas Comparison",
    "",
    `L1 source: ${l1.network}`,
    `L2 source: ${l2.network}`,
    "",
    "| Operation | L1 Gas | L2 Gas |",
    "| --- | ---: | ---: |",
    ...rows,
    ""
  ].join("\n");

  const outputPath = path.join(__dirname, "..", "docs", "gas-comparison.md");
  fs.writeFileSync(outputPath, `${report}\n`);
  console.log(report);
  console.log(`Saved gas comparison report to ${outputPath}`);
}

main();
