require("dotenv").config();

const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const deploymentPath = path.join(__dirname, "..", "deployments", `${hre.network.name}.json`);
  if (!fs.existsSync(deploymentPath)) {
    throw new Error(`Missing deployment file: ${deploymentPath}`);
  }

  const deployment = JSON.parse(fs.readFileSync(deploymentPath, "utf8"));

  for (const [name, config] of Object.entries(deployment.contracts)) {
    console.log(`Verifying ${name} at ${config.address}`);

    try {
      await hre.run("verify:verify", {
        address: config.address,
        constructorArguments: config.constructorArguments
      });
    } catch (error) {
      const message = error.message || String(error);
      if (message.includes("Already Verified")) {
        console.log(`${name} is already verified.`);
        continue;
      }

      throw error;
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
