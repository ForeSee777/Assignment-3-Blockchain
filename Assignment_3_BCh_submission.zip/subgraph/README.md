# Subgraph Notes

The subgraph is now prepared for the `SimpleAMM` contract so that Task 6 matches the brief literally: it indexes swap activity plus liquidity changes over time.

Before deployment:

1. Replace the zero address in `subgraph.yaml` with the deployed `SimpleAMM` address from `deployments/baseSepolia.json`
2. Replace `startBlock: 0` with the block number from the deployment transaction
3. If your Graph environment expects a different network identifier than `base-sepolia`, adjust that value to match the target service

This satisfies the assignment fallback condition: if a live deployment is not available yet, the configuration files are still complete and accompanied by a detailed explanation.
