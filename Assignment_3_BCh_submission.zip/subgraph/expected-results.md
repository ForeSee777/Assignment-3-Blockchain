# Expected GraphQL Results

## `GetAllSwaps`

Expected result shape:

```json
{
  "data": {
    "swaps": [
      {
        "id": "0xabc...-2",
        "trader": {
          "id": "0x123..."
        },
        "tokenIn": "0xbase...",
        "tokenOut": "0xquote...",
        "amountIn": "25000000000000000000",
        "amountOut": "24318852598970656337",
        "timestamp": "1710000200",
        "transactionHash": "0xabc..."
      }
    ]
  }
}
```

## `GetSwapsByUser`

Expected result shape:

```json
{
  "data": {
    "swaps": [
      {
        "id": "0xabc...-2",
        "tokenIn": "0xbase...",
        "tokenOut": "0xquote...",
        "amountIn": "25000000000000000000",
        "amountOut": "24318852598970656337",
        "timestamp": "1710000200",
        "transactionHash": "0xabc..."
      }
    ]
  }
}
```

## `GetTotalLiquidityOverTime`

Expected result shape:

```json
{
  "data": {
    "poolSnapshots": [
      {
        "id": "0xabc...-1",
        "reserve0": "1000000000000000000000",
        "reserve1": "1000000000000000000000",
        "totalLiquidity": "1000000000000000000000",
        "timestamp": "1710000100"
      },
      {
        "id": "0xabc...-4",
        "reserve0": "925000000000000000000",
        "reserve1": "1070000000000000000000",
        "totalLiquidity": "900000000000000000000",
        "timestamp": "1710000400"
      }
    ]
  }
}
```
