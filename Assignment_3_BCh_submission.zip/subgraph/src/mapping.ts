import { BigInt } from "@graphprotocol/graph-ts";
import {
  LiquidityAdded,
  LiquidityRemoved,
  SimpleAMM,
  Swap as SwapEvent
} from "../generated/SimpleAMM/SimpleAMM";
import { LiquidityEvent, PoolSnapshot, Swap, User } from "../generated/schema";

function getOrCreateUser(userId: string): User {
  let user = User.load(userId);
  if (user == null) {
    user = new User(userId);
    user.totalSwapCount = 0;
    user.totalLiquidityEvents = 0;
    user.totalToken0In = BigInt.zero();
    user.totalToken1In = BigInt.zero();
    user.totalToken0Out = BigInt.zero();
    user.totalToken1Out = BigInt.zero();
  }

  return user;
}

function writeSnapshot(
  eventId: string,
  reserve0: BigInt,
  reserve1: BigInt,
  totalLiquidity: BigInt,
  blockNumber: BigInt,
  timestamp: BigInt
): void {
  let snapshot = new PoolSnapshot(eventId);
  snapshot.reserve0 = reserve0;
  snapshot.reserve1 = reserve1;
  snapshot.totalLiquidity = totalLiquidity;
  snapshot.blockNumber = blockNumber;
  snapshot.timestamp = timestamp;
  snapshot.save();
}

export function handleSwap(event: SwapEvent): void {
  let amm = SimpleAMM.bind(event.address);
  let trader = getOrCreateUser(event.params.trader.toHexString());
  trader.totalSwapCount = trader.totalSwapCount + 1;

  let token0Result = amm.try_token0();
  let token0Address = token0Result.reverted ? event.params.tokenIn : token0Result.value;

  if (event.params.tokenIn == token0Address) {
    trader.totalToken0In = trader.totalToken0In.plus(event.params.amountIn);
    trader.totalToken1Out = trader.totalToken1Out.plus(event.params.amountOut);
  } else {
    trader.totalToken1In = trader.totalToken1In.plus(event.params.amountIn);
    trader.totalToken0Out = trader.totalToken0Out.plus(event.params.amountOut);
  }

  trader.save();

  let entity = new Swap(
    event.transaction.hash.toHexString().concat("-").concat(event.logIndex.toString())
  );
  entity.trader = trader.id;
  entity.tokenIn = event.params.tokenIn;
  entity.tokenOut = event.params.tokenOut;
  entity.amountIn = event.params.amountIn;
  entity.amountOut = event.params.amountOut;
  entity.reserve0After = event.params.reserve0After;
  entity.reserve1After = event.params.reserve1After;
  entity.blockNumber = event.block.number;
  entity.timestamp = event.block.timestamp;
  entity.transactionHash = event.transaction.hash;
  entity.save();

  let totalLiquidityResult = amm.try_totalLiquidity();
  writeSnapshot(
    entity.id,
    event.params.reserve0After,
    event.params.reserve1After,
    totalLiquidityResult.reverted ? BigInt.zero() : totalLiquidityResult.value,
    event.block.number,
    event.block.timestamp
  );
}

export function handleLiquidityAdded(event: LiquidityAdded): void {
  let provider = getOrCreateUser(event.params.provider.toHexString());
  provider.totalLiquidityEvents = provider.totalLiquidityEvents + 1;
  provider.totalToken0In = provider.totalToken0In.plus(event.params.amount0);
  provider.totalToken1In = provider.totalToken1In.plus(event.params.amount1);
  provider.save();

  let entity = new LiquidityEvent(
    event.transaction.hash.toHexString().concat("-").concat(event.logIndex.toString())
  );
  entity.provider = provider.id;
  entity.eventType = "ADD";
  entity.amount0 = event.params.amount0;
  entity.amount1 = event.params.amount1;
  entity.liquidityDelta = event.params.sharesMinted;
  entity.reserve0After = event.params.reserve0After;
  entity.reserve1After = event.params.reserve1After;
  entity.totalLiquidityAfter = event.params.totalLiquidityAfter;
  entity.blockNumber = event.block.number;
  entity.timestamp = event.block.timestamp;
  entity.transactionHash = event.transaction.hash;
  entity.save();

  writeSnapshot(
    entity.id,
    event.params.reserve0After,
    event.params.reserve1After,
    event.params.totalLiquidityAfter,
    event.block.number,
    event.block.timestamp
  );
}

export function handleLiquidityRemoved(event: LiquidityRemoved): void {
  let provider = getOrCreateUser(event.params.provider.toHexString());
  provider.totalLiquidityEvents = provider.totalLiquidityEvents + 1;
  provider.totalToken0Out = provider.totalToken0Out.plus(event.params.amount0);
  provider.totalToken1Out = provider.totalToken1Out.plus(event.params.amount1);
  provider.save();

  let entity = new LiquidityEvent(
    event.transaction.hash.toHexString().concat("-").concat(event.logIndex.toString())
  );
  entity.provider = provider.id;
  entity.eventType = "REMOVE";
  entity.amount0 = event.params.amount0;
  entity.amount1 = event.params.amount1;
  entity.liquidityDelta = event.params.sharesBurned.times(BigInt.fromI32(-1));
  entity.reserve0After = event.params.reserve0After;
  entity.reserve1After = event.params.reserve1After;
  entity.totalLiquidityAfter = event.params.totalLiquidityAfter;
  entity.blockNumber = event.block.number;
  entity.timestamp = event.block.timestamp;
  entity.transactionHash = event.transaction.hash;
  entity.save();

  writeSnapshot(
    entity.id,
    event.params.reserve0After,
    event.params.reserve1After,
    event.params.totalLiquidityAfter,
    event.block.number,
    event.block.timestamp
  );
}
