const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("GameItems", function () {
  async function deployFixture() {
    const [owner, alice, bob] = await ethers.getSigners();
    const gameItems = await ethers.deployContract("GameItems", [
      "https://example.com/metadata/{id}.json"
    ]);
    const holder = await ethers.deployContract("ERC1155HolderMock");
    const nonReceiver = await ethers.deployContract("NonReceiver");

    return { gameItems, holder, nonReceiver, owner, alice, bob };
  }

  it("mints fungible resources and NFTs", async function () {
    const { gameItems, alice } = await loadFixture(deployFixture);

    await gameItems.mint(alice.address, 1, 500, "0x");
    await gameItems.mint(alice.address, 1001, 1, "0x");

    expect(await gameItems.balanceOf(alice.address, 1)).to.equal(500n);
    expect(await gameItems.balanceOf(alice.address, 1001)).to.equal(1n);
  });

  it("supports batch minting for mixed token types", async function () {
    const { gameItems, alice } = await loadFixture(deployFixture);

    await gameItems.mintBatch(alice.address, [1, 2, 3, 1002], [250, 300, 150, 1], "0x");

    expect(await gameItems.balanceOf(alice.address, 1)).to.equal(250n);
    expect(await gameItems.balanceOf(alice.address, 2)).to.equal(300n);
    expect(await gameItems.balanceOf(alice.address, 3)).to.equal(150n);
    expect(await gameItems.balanceOf(alice.address, 1002)).to.equal(1n);
  });

  it("restricts minting to the owner", async function () {
    const { gameItems, alice } = await loadFixture(deployFixture);

    await expect(
      gameItems.connect(alice).mint(alice.address, 1, 1, "0x")
    ).to.be.revertedWithCustomError(gameItems, "OwnableUnauthorizedAccount");
  });

  it("transfers resources safely to an EOA", async function () {
    const { gameItems, alice, bob } = await loadFixture(deployFixture);

    await gameItems.mint(alice.address, 1, 120, "0x");
    await gameItems.connect(alice).safeTransferFrom(alice.address, bob.address, 1, 40, "0x");

    expect(await gameItems.balanceOf(alice.address, 1)).to.equal(80n);
    expect(await gameItems.balanceOf(bob.address, 1)).to.equal(40n);
  });

  it("transfers batches safely between users", async function () {
    const { gameItems, alice, bob } = await loadFixture(deployFixture);

    await gameItems.mintBatch(alice.address, [1, 2, 3], [120, 80, 30], "0x");
    await gameItems
      .connect(alice)
      .safeBatchTransferFrom(alice.address, bob.address, [1, 2], [20, 15], "0x");

    expect(await gameItems.balanceOf(bob.address, 1)).to.equal(20n);
    expect(await gameItems.balanceOf(bob.address, 2)).to.equal(15n);
    expect(await gameItems.balanceOf(alice.address, 1)).to.equal(100n);
    expect(await gameItems.balanceOf(alice.address, 2)).to.equal(65n);
  });

  it("accepts safe transfers to an ERC1155 receiver", async function () {
    const { gameItems, alice, holder } = await loadFixture(deployFixture);

    await gameItems.mint(alice.address, 1002, 1, "0x");
    await gameItems
      .connect(alice)
      .safeTransferFrom(alice.address, holder.target, 1002, 1, "0x");

    expect(await gameItems.balanceOf(holder.target, 1002)).to.equal(1n);
  });

  it("reverts transfers to contracts that do not implement ERC1155Receiver", async function () {
    const { gameItems, alice, nonReceiver } = await loadFixture(deployFixture);

    await gameItems.mint(alice.address, 1, 10, "0x");

    await expect(
      gameItems.connect(alice).safeTransferFrom(alice.address, nonReceiver.target, 1, 1, "0x")
    ).to.be.reverted;
  });

  it("crafts a legendary sword by burning the recipe resources", async function () {
    const { gameItems, alice } = await loadFixture(deployFixture);

    await gameItems.mintBatch(alice.address, [1, 2, 3], [100, 25, 10], "0x");
    await gameItems.connect(alice).craft(1001, 1);

    expect(await gameItems.balanceOf(alice.address, 1)).to.equal(0n);
    expect(await gameItems.balanceOf(alice.address, 2)).to.equal(0n);
    expect(await gameItems.balanceOf(alice.address, 3)).to.equal(0n);
    expect(await gameItems.balanceOf(alice.address, 1001)).to.equal(1n);
  });

  it("reverts crafting when the player lacks enough resources", async function () {
    const { gameItems, alice } = await loadFixture(deployFixture);

    await gameItems.mintBatch(alice.address, [1, 2, 3], [99, 25, 10], "0x");

    await expect(gameItems.connect(alice).craft(1001, 1)).to.be.reverted;
  });

  it("returns a metadata URI that uses token id substitution", async function () {
    const { gameItems } = await loadFixture(deployFixture);

    expect(await gameItems.uri(1)).to.equal("https://example.com/metadata/{id}.json");
  });
});
