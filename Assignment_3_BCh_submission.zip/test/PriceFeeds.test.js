const { loadFixture, time } = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Price feed integration", function () {
  async function deployFixture() {
    const [owner, alice] = await ethers.getSigners();
    const feed = await ethers.deployContract("MockAggregator", [
      8,
      3500n * 10n ** 8n,
      "Mock ETH / USD"
    ]);
    const consumer = await ethers.deployContract("PriceFeedConsumer", [feed.target, 3600]);
    const vault = await ethers.deployContract("PriceDependentVault", [
      feed.target,
      3600,
      3000n * 10n ** 18n
    ]);

    return { feed, consumer, vault, owner, alice };
  }

  it("normalizes Chainlink prices to 18 decimals", async function () {
    const { consumer } = await loadFixture(deployFixture);

    expect(await consumer.getLatestPrice()).to.equal(3500n * 10n ** 18n);
  });

  it("returns the feed decimals and timestamp metadata", async function () {
    const { consumer } = await loadFixture(deployFixture);
    const latestBlock = await ethers.provider.getBlock("latest");
    const [price, decimals, updatedAt] = await consumer.getLatestPriceData();

    expect(price).to.equal(3500n * 10n ** 18n);
    expect(decimals).to.equal(8);
    expect(updatedAt).to.be.at.most(BigInt(latestBlock.timestamp));
  });

  it("stores ETH deposits and reports their USD value", async function () {
    const { vault, alice } = await loadFixture(deployFixture);

    await vault.connect(alice).deposit({ value: ethers.parseEther("2") });

    expect(await vault.deposits(alice.address)).to.equal(ethers.parseEther("2"));
    expect(await vault.getDepositValueInUsd(alice.address)).to.equal(7000n * 10n ** 18n);
  });

  it("allows withdrawals when ETH remains above the configured threshold", async function () {
    const { vault, alice } = await loadFixture(deployFixture);

    await vault.connect(alice).deposit({ value: ethers.parseEther("1.5") });
    await expect(() => vault.connect(alice).withdraw(ethers.parseEther("0.5"))).to.changeEtherBalances(
      [vault, alice],
      [-ethers.parseEther("0.5"), ethers.parseEther("0.5")]
    );

    expect(await vault.deposits(alice.address)).to.equal(ethers.parseEther("1"));
  });

  it("blocks withdrawals when the price falls below the threshold", async function () {
    const { feed, vault, alice } = await loadFixture(deployFixture);

    await vault.connect(alice).deposit({ value: ethers.parseEther("1") });
    await feed.setAnswer(2500n * 10n ** 8n);

    await expect(vault.connect(alice).withdraw(ethers.parseEther("0.5")))
      .to.be.revertedWithCustomError(vault, "PriceBelowThreshold")
      .withArgs(2500n * 10n ** 18n, 3000n * 10n ** 18n);
  });

  it("reverts when price data becomes stale", async function () {
    const { feed, consumer } = await loadFixture(deployFixture);
    const staleTimestamp = (await time.latest()) - 4000;

    await feed.setRoundData(3500n * 10n ** 8n, staleTimestamp);

    await expect(consumer.getLatestPrice()).to.be.revertedWithCustomError(consumer, "StalePrice");
  });

  it("reverts on invalid non-positive prices", async function () {
    const { feed, consumer } = await loadFixture(deployFixture);

    await feed.setAnswer(-1);

    await expect(consumer.getLatestPrice())
      .to.be.revertedWithCustomError(consumer, "InvalidPrice")
      .withArgs(-1);
  });

  it("rejects zero deposits and over-withdrawals", async function () {
    const { vault, alice } = await loadFixture(deployFixture);

    await expect(vault.connect(alice).deposit({ value: 0 })).to.be.revertedWithCustomError(
      vault,
      "ZeroAmount"
    );

    await vault.connect(alice).deposit({ value: ethers.parseEther("1") });

    await expect(vault.connect(alice).withdraw(ethers.parseEther("2")))
      .to.be.revertedWithCustomError(vault, "InsufficientBalance");
  });
});
