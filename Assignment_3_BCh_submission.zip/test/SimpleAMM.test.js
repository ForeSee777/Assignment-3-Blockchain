const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("SimpleAMM", function () {
  async function deployFixture() {
    const [owner, alice] = await ethers.getSigners();
    const token0 = await ethers.deployContract("MockERC20", ["Base Asset", "BASE", 18]);
    const token1 = await ethers.deployContract("MockERC20", ["Quote Asset", "QUOTE", 18]);
    const amm = await ethers.deployContract("SimpleAMM", [token0.target, token1.target]);

    for (const user of [owner, alice]) {
      await token0.mint(user.address, ethers.parseEther("5000"));
      await token1.mint(user.address, ethers.parseEther("5000"));
      await token0.connect(user).approve(amm.target, ethers.MaxUint256);
      await token1.connect(user).approve(amm.target, ethers.MaxUint256);
    }

    return { token0, token1, amm, owner, alice };
  }

  it("creates the initial liquidity position and mints LP shares", async function () {
    const { amm, owner } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));

    expect(await amm.reserve0()).to.equal(ethers.parseEther("1000"));
    expect(await amm.reserve1()).to.equal(ethers.parseEther("1000"));
    expect(await amm.totalLiquidity()).to.equal(ethers.parseEther("1000"));
    expect(await amm.liquidityBalance(owner.address)).to.equal(ethers.parseEther("1000"));
  });

  it("requires proportional liquidity after the pool exists", async function () {
    const { amm, alice } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));

    await expect(
      amm.connect(alice).addLiquidity(ethers.parseEther("200"), ethers.parseEther("150"))
    ).to.be.revertedWithCustomError(amm, "InvalidLiquidityRatio");
  });

  it("allows proportional follow-on liquidity", async function () {
    const { amm, alice } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));
    await amm.connect(alice).addLiquidity(ethers.parseEther("200"), ethers.parseEther("200"));

    expect(await amm.liquidityBalance(alice.address)).to.equal(ethers.parseEther("200"));
    expect(await amm.totalLiquidity()).to.equal(ethers.parseEther("1200"));
  });

  it("swaps token0 for token1 and updates reserves", async function () {
    const { amm, token1, owner } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));
    const quoteBefore = await token1.balanceOf(owner.address);

    await amm.swapToken0ForToken1(ethers.parseEther("10"), 0);

    expect(await token1.balanceOf(owner.address)).to.be.gt(quoteBefore);
    expect(await amm.reserve0()).to.equal(ethers.parseEther("1010"));
    expect(await amm.reserve1()).to.be.lt(ethers.parseEther("1000"));
  });

  it("swaps token1 for token0 and updates reserves", async function () {
    const { amm, token0, owner } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));
    const baseBefore = await token0.balanceOf(owner.address);

    await amm.swapToken1ForToken0(ethers.parseEther("25"), 0);

    expect(await token0.balanceOf(owner.address)).to.be.gt(baseBefore);
    expect(await amm.reserve1()).to.equal(ethers.parseEther("1025"));
    expect(await amm.reserve0()).to.be.lt(ethers.parseEther("1000"));
  });

  it("removes liquidity proportionally", async function () {
    const { amm, token0, token1, owner } = await loadFixture(deployFixture);

    await amm.addLiquidity(ethers.parseEther("1000"), ethers.parseEther("1000"));
    await amm.removeLiquidity(ethers.parseEther("400"));

    expect(await amm.totalLiquidity()).to.equal(ethers.parseEther("600"));
    expect(await amm.reserve0()).to.equal(ethers.parseEther("600"));
    expect(await amm.reserve1()).to.equal(ethers.parseEther("600"));
    expect(await token0.balanceOf(owner.address)).to.equal(ethers.parseEther("4400"));
    expect(await token1.balanceOf(owner.address)).to.equal(ethers.parseEther("4400"));
  });
});
