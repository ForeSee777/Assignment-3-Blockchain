const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Vault", function () {
  async function deployFixture() {
    const [owner, alice, bob] = await ethers.getSigners();
    const token = await ethers.deployContract("MockERC20", ["Vault Asset", "VAST", 18]);
    const vault = await ethers.deployContract("Vault", [token.target, "Assignment Vault Share", "aVAST"]);

    await token.mint(alice.address, ethers.parseEther("1000"));
    await token.mint(bob.address, ethers.parseEther("1000"));
    await token.mint(owner.address, ethers.parseEther("1000"));

    return { token, vault, owner, alice, bob };
  }

  it("mints one share per asset on the initial deposit", async function () {
    const { token, vault, alice } = await loadFixture(deployFixture);
    const amount = ethers.parseEther("100");

    await token.connect(alice).approve(vault.target, amount);
    await vault.connect(alice).deposit(amount, alice.address);

    expect(await vault.balanceOf(alice.address)).to.equal(amount);
    expect(await vault.totalAssets()).to.equal(amount);
  });

  it("supports minting a target amount of shares", async function () {
    const { token, vault, bob } = await loadFixture(deployFixture);
    const shares = ethers.parseEther("50");

    await token.connect(bob).approve(vault.target, shares);
    await vault.connect(bob).mint(shares, bob.address);

    expect(await vault.balanceOf(bob.address)).to.equal(shares);
    expect(await token.balanceOf(vault.target)).to.equal(shares);
  });

  it("supports partial withdrawals", async function () {
    const { token, vault, alice } = await loadFixture(deployFixture);
    const depositAmount = ethers.parseEther("100");
    const withdrawAmount = ethers.parseEther("40");

    await token.connect(alice).approve(vault.target, depositAmount);
    await vault.connect(alice).deposit(depositAmount, alice.address);
    await vault.connect(alice).withdraw(withdrawAmount, alice.address, alice.address);

    expect(await vault.balanceOf(alice.address)).to.equal(ethers.parseEther("60"));
    expect(await token.balanceOf(alice.address)).to.equal(ethers.parseEther("940"));
  });

  it("supports redeeming shares back into assets", async function () {
    const { token, vault, alice } = await loadFixture(deployFixture);
    const depositAmount = ethers.parseEther("75");

    await token.connect(alice).approve(vault.target, depositAmount);
    await vault.connect(alice).deposit(depositAmount, alice.address);
    await vault.connect(alice).redeem(ethers.parseEther("25"), alice.address, alice.address);

    expect(await vault.balanceOf(alice.address)).to.equal(ethers.parseEther("50"));
    expect(await token.balanceOf(alice.address)).to.equal(ethers.parseEther("950"));
  });

  it("increases share value after harvest adds yield", async function () {
    const { token, vault, owner, alice } = await loadFixture(deployFixture);

    await token.connect(alice).approve(vault.target, ethers.parseEther("100"));
    await vault.connect(alice).deposit(ethers.parseEther("100"), alice.address);

    await token.connect(owner).approve(vault.target, ethers.parseEther("50"));
    await vault.harvest(ethers.parseEther("50"));

    expect(await vault.totalAssets()).to.equal(ethers.parseEther("150"));
    expect(await vault.convertToAssets(ethers.parseEther("100"))).to.equal(ethers.parseEther("150"));
  });

  it("gives late depositors fewer shares when the share price has increased", async function () {
    const { token, vault, owner, alice, bob } = await loadFixture(deployFixture);

    await token.connect(alice).approve(vault.target, ethers.parseEther("100"));
    await vault.connect(alice).deposit(ethers.parseEther("100"), alice.address);

    await token.connect(owner).approve(vault.target, ethers.parseEther("50"));
    await vault.harvest(ethers.parseEther("50"));

    await token.connect(bob).approve(vault.target, ethers.parseEther("30"));
    await vault.connect(bob).deposit(ethers.parseEther("30"), bob.address);

    expect(await vault.balanceOf(bob.address)).to.equal(ethers.parseEther("20"));
  });

  it("uses ERC4626 conversion math with rounding after yield accrues", async function () {
    const { token, vault, owner, alice } = await loadFixture(deployFixture);

    await token.connect(alice).approve(vault.target, ethers.parseEther("100"));
    await vault.connect(alice).deposit(ethers.parseEther("100"), alice.address);

    await token.connect(owner).approve(vault.target, ethers.parseEther("50"));
    await vault.harvest(ethers.parseEther("50"));

    expect(await vault.convertToShares(ethers.parseEther("1"))).to.equal(666666666666666666n);
    expect(await vault.convertToAssets(ethers.parseEther("1"))).to.equal(1500000000000000000n);
  });

  it("tracks the maximum assets a depositor can withdraw", async function () {
    const { token, vault, owner, alice } = await loadFixture(deployFixture);

    await token.connect(alice).approve(vault.target, ethers.parseEther("100"));
    await vault.connect(alice).deposit(ethers.parseEther("100"), alice.address);

    await token.connect(owner).approve(vault.target, ethers.parseEther("50"));
    await vault.harvest(ethers.parseEther("50"));

    expect(await vault.maxWithdraw(alice.address)).to.equal(ethers.parseEther("150"));
  });

  it("restricts harvest to the owner and rejects zero-value harvests", async function () {
    const { token, vault, alice } = await loadFixture(deployFixture);

    await token.connect(alice).approve(vault.target, ethers.parseEther("1"));

    await expect(vault.connect(alice).harvest(ethers.parseEther("1"))).to.be.revertedWithCustomError(
      vault,
      "OwnableUnauthorizedAccount"
    );

    await expect(vault.harvest(0)).to.be.revertedWith("Vault: zero harvest");
  });
});
